#!/usr/bin/env python
# coding=utf-8

configs = {
    'db' : {
        'host' : '127.0.0.1'
    }
}
