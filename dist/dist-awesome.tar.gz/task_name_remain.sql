use awesome;

create table task_name_remain (
	id integer not null primary key,
	
)