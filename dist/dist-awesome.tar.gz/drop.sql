use awesome;
drop table deviceInfo;

