use awesome;
drop table ip_dev_info;

