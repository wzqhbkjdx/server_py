use awesome;

create table remain (
    id integer not null AUTO_INCREMENT primary key,
    idenf varchar(50),
    num varchar(50)
) engine=innodb default charset=utf8;
